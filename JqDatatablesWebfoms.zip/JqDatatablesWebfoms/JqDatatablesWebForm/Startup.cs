﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(JqDatatablesWebForm.Startup))]
namespace JqDatatablesWebForm
{
    public partial class Startup {
        public void Configuration(IAppBuilder app) {
            ConfigureAuth(app);
        }
    }
}
